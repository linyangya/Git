package com.syc.oa.vo;

public class SignChart {
	
	private String day;// 签到日期
	private long num;// 签到人数

	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public long getNum() {
		return num;
	}

	public void setNum(long num) {
		this.num = num;
	}

}
