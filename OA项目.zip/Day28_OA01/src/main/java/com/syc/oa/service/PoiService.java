package com.syc.oa.service;

public interface PoiService {

	public String createExcel(String username);
}
